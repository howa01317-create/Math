package com.example.mathsolver

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private lateinit var input: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(Color.WHITE)
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "حلال الرياضيات"
            textSize = 30f
            setTextColor(Color.rgb(25, 25, 25))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        val help = TextView(this).apply {
            text = "اكتب معادلة مثل: 2x + 5 = 15 أو x^2 - 5x + 6 = 0"
            textSize = 16f
            setPadding(0, 0, 0, 18)
        }

        input = EditText(this).apply {
            hint = "اكتب المعادلة هنا"
            textSize = 20f
            setSingleLine(true)
        }

        val solve = Button(this).apply {
            text = "حل المعادلة"
            textSize = 18f
            setOnClickListener { solveEquation() }
        }

        val clear = Button(this).apply {
            text = "مسح"
            setOnClickListener {
                input.text.clear()
                result.text = ""
            }
        }

        result = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.rgb(20, 80, 40))
            setPadding(0, 24, 0, 0)
        }

        root.addView(title)
        root.addView(help)
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        root.addView(solve, LinearLayout.LayoutParams(-1, -2))
        root.addView(clear, LinearLayout.LayoutParams(-1, -2))
        root.addView(result, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    private fun solveEquation() {
        val raw = input.text.toString()
            .replace(" ", "")
            .replace("×", "*")
            .replace("−", "-")

        if (!raw.contains("=")) {
            result.text = "اكتب معادلة تحتوي على ="
            return
        }

        try {
            val parts = raw.split("=")
            if (parts.size != 2) throw Exception()

            val left = parts[0]
            val right = parts[1]

            val degree = if (left.contains("^2") || right.contains("^2")) 2 else 1

            if (degree == 1) {
                val a = coefficient(left, 1) - coefficient(right, 1)
                val b = constant(left) - constant(right)

                if (a == 0.0) {
                    result.text = if (b == 0.0) "عدد لا نهائي من الحلول" else "لا يوجد حل"
                    return
                }

                val x = -b / a
                result.text = "خطوات الحل:\n" +
                        "$a x + $b = 0\n" +
                        "$a x = ${-b}\n" +
                        "x = $x"
            } else {
                val a = coefficient(left, 2) - coefficient(right, 2)
                val b = coefficient(left, 1) - coefficient(right, 1)
                val c = constant(left) - constant(right)

                if (a == 0.0) {
                    val x = if (b != 0.0) -c / b else Double.NaN
                    result.text = "المعادلة اختزلت إلى:\nx = $x"
                    return
                }

                val d = b*b - 4*a*c

                result.text = when {
                    d < 0 -> "Δ = $d\nلا توجد حلول حقيقية."
                    d == 0.0 -> {
                        val x = -b / (2*a)
                        "Δ = 0\nحل واحد:\nx = $x"
                    }
                    else -> {
                        val x1 = (-b + kotlin.math.sqrt(d)) / (2*a)
                        val x2 = (-b - kotlin.math.sqrt(d)) / (2*a)
                        "Δ = $d\nالحلان:\nx₁ = $x1\nx₂ = $x2"
                    }
                }
            }
        } catch (e: Exception) {
            result.text = "تعذر فهم المعادلة.\nاستخدم مثلًا: 2x+5=15"
        }
    }

    private fun coefficient(expr: String, degree: Int): Double {
        val normalized = expr.replace("-", "+-")
        var total = 0.0
        for (term0 in normalized.split("+")) {
            val term = term0
            if (term.isEmpty()) continue
            if (degree == 2 && term.contains("x^2")) {
                total += parseCoeff(term.substringBefore("x^2"))
            } else if (degree == 1 && term.contains("x") && !term.contains("^2")) {
                total += parseCoeff(term.substringBefore("x"))
            }
        }
        return total
    }

    private fun constant(expr: String): Double {
        val normalized = expr.replace("-", "+-")
        var total = 0.0
        for (term in normalized.split("+")) {
            if (term.isNotEmpty() && !term.contains("x")) {
                total += term.toDouble()
            }
        }
        return total
    }

    private fun parseCoeff(s: String): Double {
        return when (s) {
            "", "+" -> 1.0
            "-" -> -1.0
            else -> s.toDouble()
        }
    }
}
